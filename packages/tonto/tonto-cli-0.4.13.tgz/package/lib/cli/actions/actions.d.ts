import { ImportOptions } from "./commands/importCommand.js";
export type GenerateOptions = {
    destination?: string;
};
export type ValidateOptions = {
    local: boolean;
};
export type GeneratePlantUMLOptions = {
    destination?: string;
    perPackage?: boolean;
    externalReferences?: boolean;
    layout?: string;
};
export declare class TontoActions {
    /**
   * This action imports a JSON File and create a Tonto Project based on it
   * @param opts An object containing options for importing
   */
    importAction(fileName: string, dir?: ImportOptions): Promise<void>;
    importSingleAction(fileName: string, dir?: ImportOptions): Promise<void>;
    generateAction(dirName: string, opts: GenerateOptions): Promise<void>;
    generateSingleAction(fileName: string, opts: GenerateOptions): Promise<void>;
    transformToGufoAction(dirName: string): Promise<void>;
    generatePlantUMLAction(dirName: string, opts?: GeneratePlantUMLOptions): Promise<void>;
    validateAction(dirName: string, opts: {
        withApi?: boolean;
    }): Promise<void>;
}
//# sourceMappingURL=actions.d.ts.map