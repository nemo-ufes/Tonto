import { Command } from "commander";
export type SkillProjectFile = {
    type: "file" | "dir";
    relativePath: string;
    content?: string;
};
export declare const SKILL_TARGET_OPTIONS: readonly [{
    readonly label: "Cursor";
    readonly value: "cursor";
    readonly description: "Install the Tonto skill under .cursor/skills/tonto-ontology";
}, {
    readonly label: "VS Code";
    readonly value: "vscode";
    readonly description: "Install the Tonto skill under .github/skills/tonto-ontology";
}, {
    readonly label: "Codex";
    readonly value: "codex";
    readonly description: "Install the Tonto skill under .codex/skills/tonto-ontology";
}, {
    readonly label: "Claude Code";
    readonly value: "claude";
    readonly description: "Install the Tonto skill under .claude/skills/tonto-ontology";
}, {
    readonly label: "Google (Gemini / Antigravity)";
    readonly value: "google";
    readonly description: "Install the Tonto skill under .agents/skills/tonto-ontology";
}, {
    readonly label: "All";
    readonly value: "all";
    readonly description: "Install the Tonto skill for every supported editor and agentic IDE";
}];
export type SkillTargetChoice = (typeof SKILL_TARGET_OPTIONS)[number]["value"];
export declare function buildTontoSkillProjectFiles(projectName: string): SkillProjectFile[];
export declare function shouldIncludeTemplatePathForSkillTarget(skillTarget: SkillTargetChoice, relativePath: string): boolean;
export declare function addSkillCommand(): Command;
//# sourceMappingURL=addSkillCommand.d.ts.map