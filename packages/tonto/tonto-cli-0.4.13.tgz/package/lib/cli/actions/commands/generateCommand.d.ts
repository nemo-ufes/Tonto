export declare const generateCommand: (fileName: string, destination: string) => Promise<string | undefined>;
export declare function generateModularCommand(dir: string, label?: string, description?: string): Promise<string | undefined>;
//# sourceMappingURL=generateCommand.d.ts.map