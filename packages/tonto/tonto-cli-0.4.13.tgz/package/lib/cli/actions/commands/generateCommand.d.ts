export declare const generateCommand: (fileName: string, destination?: string) => Promise<string>;
export declare function generateModularCommand(dir: string, label?: string, description?: string, destination?: string): Promise<string>;
//# sourceMappingURL=generateCommand.d.ts.map