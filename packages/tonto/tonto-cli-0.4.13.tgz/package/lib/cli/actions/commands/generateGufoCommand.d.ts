import { ErrorGufoResultResponse, GufoResultResponse } from "../../main.js";
export declare const transformToGufoCommand: (dirName: string, label?: string, description?: string) => Promise<GufoResultResponse | ErrorGufoResultResponse>;
export declare function isGufoResultResponse(value: unknown): value is GufoResultResponse;
//# sourceMappingURL=generateGufoCommand.d.ts.map