export interface GeneratePlantUMLCommandOptions {
    destination?: string;
    perPackage?: boolean;
    showExternalReferences?: boolean;
    layout?: string;
}
export declare function generatePlantUMLCommand(dir: string, options?: GeneratePlantUMLCommandOptions): Promise<string[]>;
//# sourceMappingURL=generatePlantUMLCommand.d.ts.map