import { type TontoGenerationError } from "../../requests/tontoGeneration.js";
export type ImportOptions = {
    fileName: string;
    destination?: string;
};
export type ImportReturn = {
    success: boolean;
    message: string;
    filePath?: string;
    error?: TontoGenerationError;
};
export declare const importCommand: (opts: ImportOptions) => Promise<ImportReturn>;
export declare const newImportCommand: (opts: ImportOptions) => Promise<void>;
//# sourceMappingURL=importCommand.d.ts.map