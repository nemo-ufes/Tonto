import { Command } from 'commander';
import { TontoManifest } from '../../model/grammar/TontoManifest.js';
interface InitOptions {
    catDogExample?: boolean;
    destination?: string;
    guidance?: string;
    template?: string;
}
export type InitProjectFile = {
    type: 'file' | 'dir';
    relativePath: string;
    content?: string;
};
export interface InitManifestAnswers {
    projectName: string;
    displayName?: string;
    version?: string;
    description?: string;
    license?: string;
    authorName?: string;
    authorEmail?: string;
}
export declare const GUIDANCE_TARGET_OPTIONS: readonly [{
    readonly label: "Cursor";
    readonly value: "cursor";
    readonly description: "Generate guidance under .cursor/rules with .mdc files";
}, {
    readonly label: "VS Code";
    readonly value: "vscode";
    readonly description: "Generate guidance under .github/instructions for Copilot and VS Code";
}, {
    readonly label: "Codex";
    readonly value: "codex";
    readonly description: "Generate guidance under .codex with markdown files";
}, {
    readonly label: "Claude Code";
    readonly value: "claude";
    readonly description: "Generate guidance under .claude with markdown files";
}, {
    readonly label: "Google (Gemini / Antigravity)";
    readonly value: "google";
    readonly description: "Generate guidance under .agents with markdown files for Gemini-based tools such as Antigravity";
}, {
    readonly label: "All";
    readonly value: "all";
    readonly description: "Generate guidance for every supported editor and agentic IDE";
}];
export type GuidanceTargetChoice = (typeof GUIDANCE_TARGET_OPTIONS)[number]['value'];
export declare function buildGuidanceProjectFiles(projectName: string): InitProjectFile[];
export declare function shouldIncludeTemplatePathForGuidanceTarget(guidanceTarget: GuidanceTargetChoice, relativePath: string): boolean;
export declare function buildInitManifest(answers: InitManifestAnswers): TontoManifest;
export declare function initCommand(): Command;
export declare function buildInitProjectFiles(projectName: string, options: InitOptions): InitProjectFile[];
export {};
//# sourceMappingURL=initCommand.d.ts.map