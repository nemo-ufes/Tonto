import { ErrorResultResponse, ValidationReturn } from "../../main.js";
export declare const validateCommand: (dirName?: string, locally?: boolean) => Promise<ValidationReturn | ErrorResultResponse>;
//# sourceMappingURL=validateCommand.d.ts.map