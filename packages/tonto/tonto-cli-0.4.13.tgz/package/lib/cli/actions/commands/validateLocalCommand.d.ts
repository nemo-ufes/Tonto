import { Diagnostic } from "vscode-languageserver-types";
export declare const validateCommandLocal: (dirName: string) => Promise<Diagnostic[] | undefined>;
//# sourceMappingURL=validateLocalCommand.d.ts.map