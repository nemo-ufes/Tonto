type InitOptions = {
    catDogExample?: boolean;
};
export declare function initAction(projectName: string, options: InitOptions): Promise<void>;
export {};
//# sourceMappingURL=initAction.d.ts.map