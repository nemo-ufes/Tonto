import { AstNode, LangiumDocument, LangiumDocuments } from "langium";
import { LangiumServices } from "langium/lsp";
import { Diagnostic } from "vscode-languageserver-types";
import { BuiltInLib } from "./model/BuiltInLib.js";
export declare function extractAllDocuments(fileNames: string[], services: LangiumServices, builtInLibs: BuiltInLib[], validationChecks: boolean): Promise<LangiumDocuments>;
export declare function extractDocument(fileName: string, services: LangiumServices): Promise<LangiumDocument>;
export declare function extractAllValidationErrors(fileNames: string[], services: LangiumServices, builtInLibs: BuiltInLib[]): Promise<Diagnostic[]>;
export declare function extractAllAstNodes<T extends AstNode>(fileNames: string[], services: LangiumServices, builtInLibs: BuiltInLib[], validationChecks: boolean): Promise<T[]>;
export declare function extractAstNode<T extends AstNode>(fileName: string, services: LangiumServices): Promise<T>;
interface FilePathData {
    destination: string;
    name: string;
}
export declare function extractDestinationAndName(filePath: string, destination: string | undefined): FilePathData;
export declare function extractName(filePath: string): string;
export {};
//# sourceMappingURL=cli-util.d.ts.map