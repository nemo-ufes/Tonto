import { CompositeGeneratorNode } from "langium/generate";
import { Class, Property } from "ontouml-js";
export declare function constructAttributes(attributes: Property[], fileNode: CompositeGeneratorNode, owner: Class): void;
//# sourceMappingURL=attributes.constructor.d.ts.map