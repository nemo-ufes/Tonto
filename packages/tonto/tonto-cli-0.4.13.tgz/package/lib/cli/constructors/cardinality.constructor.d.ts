import { CompositeGeneratorNode } from "langium/generate";
import { Cardinality } from "ontouml-js";
export declare function constructCardinality(cardinality: Cardinality, fileNode: CompositeGeneratorNode): void;
//# sourceMappingURL=cardinality.constructor.d.ts.map