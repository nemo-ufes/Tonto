import { CompositeGeneratorNode } from "langium/generate";
import { Class, ClassStereotype } from "ontouml-js";
export declare function constructClassElement(element: Class, fileNode: CompositeGeneratorNode): void;
export declare function getStereotypeWord(stereotype: ClassStereotype): string;
//# sourceMappingURL=classElement.constructor.d.ts.map