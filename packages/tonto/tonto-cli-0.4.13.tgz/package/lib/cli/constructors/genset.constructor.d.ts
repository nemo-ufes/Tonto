import { CompositeGeneratorNode } from "langium/generate";
import { GeneralizationSet } from "ontouml-js";
export declare function constructGenSet(element: GeneralizationSet, fileNode: CompositeGeneratorNode): void;
//# sourceMappingURL=genset.constructor.d.ts.map