import { CompositeGeneratorNode } from "langium/generate";
import { Package } from "ontouml-js";
export declare function createTontoImports(actualPackage: Package, fileNode: CompositeGeneratorNode): void;
//# sourceMappingURL=importModular.constructor.d.ts.map