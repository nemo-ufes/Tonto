import { Project } from "ontouml-js";
export declare function generateTontoFile(project: Project, filePath: string, destination: string | undefined): string;
//# sourceMappingURL=index.d.ts.map