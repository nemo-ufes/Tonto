import { CompositeGeneratorNode } from "langium/generate";
import { Class } from "ontouml-js";
export declare function createInstantiation(element: Class, fileNode: CompositeGeneratorNode): void;
//# sourceMappingURL=instantiation.constructor.d.ts.map