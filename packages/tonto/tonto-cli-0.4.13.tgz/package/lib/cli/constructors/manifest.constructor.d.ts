import { Project } from "ontouml-js";
export declare function createTontoManifest(project: Project, destination: string): void;
interface FilePathData {
    destination: string;
    name: string;
}
export declare function customExtractDestinationAndName(filePath: string, destination: string | undefined): FilePathData;
export {};
//# sourceMappingURL=manifest.constructor.d.ts.map