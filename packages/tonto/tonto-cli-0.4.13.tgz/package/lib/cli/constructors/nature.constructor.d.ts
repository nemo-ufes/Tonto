export {};
//# sourceMappingURL=nature.constructor.d.ts.map