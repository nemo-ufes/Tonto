import { CompositeGeneratorNode } from "langium/generate";
import { OntoumlElement } from "ontouml-js";
import { Generated } from "langium/generate";
/**
 * This function is the entry point for creating a Tonto Model based on an OntoUML
 * element.
 * @param element The parsed OntoUML Element from ontouml-js
 * @param fileNode The node which the generated file is created
 * @returns
 */
export declare function createTontoPackage(packageItem: OntoumlElement, fileNode: CompositeGeneratorNode): Generated;
export declare function generateTonto(element: OntoumlElement): Generated;
//# sourceMappingURL=package.constructor.d.ts.map