import { CompositeGeneratorNode } from "langium/generate";
import { Class, Relation } from "ontouml-js";
export declare function constructInternalRelations(element: Class, relations: Relation[], fileNode: CompositeGeneratorNode): void;
export declare function constructExternalRelations(relations: Relation[], fileNode: CompositeGeneratorNode): void;
//# sourceMappingURL=relation.constructor.d.ts.map