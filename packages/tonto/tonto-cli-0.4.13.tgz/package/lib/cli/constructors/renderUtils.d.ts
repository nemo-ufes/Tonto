import { CompositeGeneratorNode } from "langium/generate";
import { Cardinality, MultilingualText, OntoumlElement } from "ontouml-js";
type NameCarrier = {
    id?: string;
    propertyAssignments?: object | null;
    getName?: () => string | null;
};
export declare function formatTontoIdentifier(name: string | null | undefined): string;
export declare function formatTontoQualifiedName(name: string | null | undefined): string;
export declare function getRenderableElementName(element: NameCarrier | undefined): string | undefined;
export declare function formatElementReference(element: OntoumlElement | NameCarrier | undefined, currentPackageName: string | undefined): string;
export declare function appendLabelAndDescription(element: {
    name?: MultilingualText | null;
    description?: MultilingualText | null;
}, identifier: string, fileNode: CompositeGeneratorNode): void;
export declare function hasRenderableDocumentation(element: {
    name?: MultilingualText | null;
    description?: MultilingualText | null;
}, identifier: string): boolean;
export declare function isDefaultCardinality(cardinality: Cardinality | undefined): boolean;
export declare function getContainingPackageName(element: OntoumlElement | undefined): string | undefined;
export declare function isBuiltInTontoPackage(packageName: string | undefined): boolean;
export {};
//# sourceMappingURL=renderUtils.d.ts.map