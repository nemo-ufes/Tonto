import { CompositeGeneratorNode } from "langium/generate";
import { Class } from "ontouml-js";
export declare function createSpecializations(element: Class, fileNode: CompositeGeneratorNode): void;
//# sourceMappingURL=specialization.constructor.d.ts.map