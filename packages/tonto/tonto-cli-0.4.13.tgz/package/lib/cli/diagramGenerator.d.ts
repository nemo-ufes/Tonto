import { Class, Generalization, GeneralizationSet, Package, Relation } from "ontouml-js";
import { Model } from "../language/index.js";
export interface diagramContent {
    packages: Package;
    class: Array<Class>;
    specializations: Array<Generalization>;
    specializationSets: Array<GeneralizationSet>;
    relations: Array<Relation>;
}
export declare function extractContent(model: Model, name: string | undefined): diagramContent;
//# sourceMappingURL=diagramGenerator.d.ts.map