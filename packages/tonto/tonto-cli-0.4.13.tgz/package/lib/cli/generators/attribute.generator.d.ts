import { Class } from "ontouml-js";
import { ClassDeclaration, DataType } from "../../language/generated/ast.js";
export declare function attributeGenerator(classElement: ClassDeclaration | DataType, createdClass: Class, dataTypes: Class[], resolveDataType?: (dataType: DataType | undefined) => Class | undefined): void;
//# sourceMappingURL=attribute.generator.d.ts.map