import { Property } from "ontouml-js";
import { Cardinality } from "../../language/generated/ast.js";
export declare function setPropertyCardinality(cardinality: Cardinality | undefined, end: Property): void;
//# sourceMappingURL=cardinality.generator.d.ts.map