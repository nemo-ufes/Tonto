import { Class, Package } from "ontouml-js";
import { ClassDeclaration } from "../../language/generated/ast.js";
export declare function classElementGenerator(classElement: ClassDeclaration, packageItem: Package): Class;
export declare function generalizationGenerator(model: Package, sourceClass: Class, targetClass: Class): void;
export declare function createInstantiation(_model: Package, _sourceClass: Class, _targetClass: Class): void;
//# sourceMappingURL=class.generator.d.ts.map