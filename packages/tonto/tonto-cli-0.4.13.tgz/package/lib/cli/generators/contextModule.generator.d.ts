import { Package } from "ontouml-js";
import { ContextModule } from "../../language/index.js";
export declare function contextModuleGenerator(contextModule: ContextModule, packageItem: Package): void;
//# sourceMappingURL=contextModule.generator.d.ts.map