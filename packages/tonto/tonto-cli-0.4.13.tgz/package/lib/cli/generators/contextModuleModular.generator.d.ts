import { Class, Package, Relation } from "ontouml-js";
import { ClassDeclaration, ContextModule, DataType, ElementRelation } from "../../language/generated/ast.js";
export interface GeneratedContextModuleData {
    classes: Class[];
    dataTypes: Class[];
    enums: Class[];
    relations: Relation[];
    classByDeclaration: Map<ClassDeclaration, Class>;
    dataTypeByDeclaration: Map<DataType, Class>;
    relationByDeclaration: Map<ElementRelation, Relation>;
}
export declare function contextModuleGenerateClasses(contextModule: ContextModule, packageItem: Package): GeneratedContextModuleData;
export declare function contextModuleGenerateRelations(contextModule: ContextModule, packageItem: Package, modelData: GeneratedContextModuleData, importedData: GeneratedContextModuleData[]): void;
export declare function contextModuleModularGenerator(contextModule: ContextModule, modelData: GeneratedContextModuleData, packageItem: Package, importedData: GeneratedContextModuleData[]): void;
//# sourceMappingURL=contextModuleModular.generator.d.ts.map