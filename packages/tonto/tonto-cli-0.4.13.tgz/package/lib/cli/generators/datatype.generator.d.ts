import { Class, Package } from "ontouml-js";
import { DataType } from "../../language/generated/ast.js";
export declare function customDataTypeGenerator(dataType: DataType, model: Package): Class;
export declare function customDataTypeAttributesGenerator(dataType: DataType, dataTypes: Class[], resolveDataType?: (dataType: DataType | undefined) => Class | undefined): void;
//# sourceMappingURL=datatype.generator.d.ts.map