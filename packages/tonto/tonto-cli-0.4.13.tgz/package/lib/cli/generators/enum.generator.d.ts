import { Class, Package } from "ontouml-js";
import { DataType } from "../../language/index.js";
export declare function enumGenerator(enumData: DataType, model: Package): Class;
//# sourceMappingURL=enum.generator.d.ts.map