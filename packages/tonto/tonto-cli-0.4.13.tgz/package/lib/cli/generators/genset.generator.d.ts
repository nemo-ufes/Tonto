import { Class, GeneralizationSet, Package } from "ontouml-js";
import { ClassDeclaration, GeneralizationSet as GenSetData } from "../../language/generated/ast.js";
export declare function generalizationSetGenerator(enumData: GenSetData, classes: Class[], model: Package, resolveClass?: (classDeclaration: ClassDeclaration | undefined) => Class | undefined): GeneralizationSet | undefined;
//# sourceMappingURL=genset.generator.d.ts.map