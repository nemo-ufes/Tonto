import { Class, Package, Relation } from "ontouml-js";
import { ClassDeclaration, ContextModule } from "../../language/index.js";
export declare function generateInstantiations(contextModule: ContextModule, classes: Class[], _relations: Relation[], packageItem: Package, resolveClass?: (classDeclaration: ClassDeclaration | undefined) => Class | undefined): void;
//# sourceMappingURL=instantiation.generator.d.ts.map