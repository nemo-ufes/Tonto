import { Model } from "../../language/index.js";
import { TontoManifest } from "../model/grammar/TontoManifest.js";
export declare function generateJSONFileModular(models: Model[], tontoManifest: TontoManifest, folderAbsolutePath: string, label?: string, description?: string, destination?: string): string;
//# sourceMappingURL=jsonModular.generator.d.ts.map