import { Class, Package, Relation } from "ontouml-js";
import { ClassDeclaration, ElementRelation } from "../../language/generated/ast.js";
export declare function getElementRelationLookupKey(relationItem: ElementRelation, sourceClassIncoming?: ClassDeclaration): string | undefined;
export declare function findGeneratedRelation(relations: Relation[], relationItem: ElementRelation | undefined, sourceClassIncoming?: ClassDeclaration, resolveRelation?: (relationItem: ElementRelation | undefined) => Relation | undefined): Relation | undefined;
export declare function relationGenerator(relationItem: ElementRelation, packageItem: Package, classes: Class[], sourceClassIncoming?: ClassDeclaration, resolveClass?: (classDeclaration: ClassDeclaration | undefined) => Class | undefined): Relation | undefined;
export declare function relationGeneralizationGenerator(model: Package, sourceRelation: Relation, targetRelation: Relation): void;
//# sourceMappingURL=relation.generator.d.ts.map