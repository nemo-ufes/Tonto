export {};
//# sourceMappingURL=relationSpecialization.generator.d.ts.map