import { Class } from "ontouml-js";
export declare function findGeneratedDataType(dataTypes: Class[], identifier: string | undefined): Class | undefined;
//# sourceMappingURL=findGeneratedDataType.d.ts.map