/**
 * Generates a unique identifier string
 * Format: 20 lowercase alphanumeric characters
 * Example: "16gprmej15r4mimcjfbm"
 */
export declare function generateUniqueId(): string;
//# sourceMappingURL=idGenerator.d.ts.map