import { MultilingualText } from "ontouml-js";
import { Description, Label } from "../../../language/generated/ast.js";
export declare function getMultilingualText(label: Label | undefined, defaultText: string): MultilingualText;
export declare function getDescription(description: Description | undefined): MultilingualText | undefined;
//# sourceMappingURL=labelUtils.d.ts.map