import { CompositeGeneratorNode } from "langium/generate";
import { Model } from "../language/index.js";
import { ParseProjectContext } from "./utils/parseProject.js";
export declare function generateJSONFile(model: Model, filePath: string, destination: string | undefined): string;
export interface GeneratorContext extends ParseProjectContext {
    fileName: string;
    destination: string;
    fileNode: CompositeGeneratorNode;
}
//# sourceMappingURL=jsonGenerator.d.ts.map