export declare const cliVersion = "0.4.0";
export default function (): void;
export * from "./actions/index.js";
export * from "./requests/jsonGeneration.js";
export * from "./requests/tontoGeneration.js";
export * from "./model/grammar/TontoManifest.js";
export * from "./requests/gufoTransform.js";
export * from "./requests/ontoumljsValidator.js";
export * from "./utils/buildFolderDocuments.js";
export * from "./utils/readManifest.js";
//# sourceMappingURL=main.d.ts.map