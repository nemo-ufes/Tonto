export interface BuiltInLib {
    uri: string;
    content: string;
}
//# sourceMappingURL=BuiltInLib.d.ts.map