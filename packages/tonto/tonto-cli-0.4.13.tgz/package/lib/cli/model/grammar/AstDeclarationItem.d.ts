import { CompositeGeneratorNode } from "langium/generate";
export declare abstract class ASTDeclarationItem {
    abstract writeToNode(node: CompositeGeneratorNode): void;
    abstract getNumberOfInternalElements(): number;
}
//# sourceMappingURL=AstDeclarationItem.d.ts.map