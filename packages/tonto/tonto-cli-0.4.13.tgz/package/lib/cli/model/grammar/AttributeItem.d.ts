import { CompositeGeneratorNode } from "langium/generate";
import { Property } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
import { CardinalityItem } from "./CardinalityItem.js";
export declare class AttributeItem extends ASTDeclarationItem {
    name: string;
    nameSlug: string;
    type?: string;
    isConst: boolean;
    isOrdered: boolean;
    isDerived: boolean;
    cardinality: CardinalityItem;
    constructor(property: Property);
    writeToNode(node: CompositeGeneratorNode): void;
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=AttributeItem.d.ts.map