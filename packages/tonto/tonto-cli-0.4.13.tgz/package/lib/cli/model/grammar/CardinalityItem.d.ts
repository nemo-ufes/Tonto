import { CompositeGeneratorNode } from "langium/generate";
import { Cardinality } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
export declare class CardinalityItem extends ASTDeclarationItem {
    lowerBound: string | undefined;
    upperBound: string | undefined;
    constructor(cardinality: Cardinality);
    writeToNode(node: CompositeGeneratorNode): void;
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=CardinalityItem.d.ts.map