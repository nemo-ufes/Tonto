import { CompositeGeneratorNode } from "langium/generate";
import { Class, Package } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
import { AttributeItem } from "./AttributeItem.js";
import { RelationItem } from "./RelationItem.js";
export declare class ClassDeclarationItem extends ASTDeclarationItem {
    ontoumlClass: Class;
    rootPackageName: string;
    name: string;
    nameSlug: string;
    ontologicalCategory: string;
    ontologicalNatures: string[];
    specializations: string[];
    attributes: AttributeItem[];
    relations: RelationItem[];
    constructor(ontoumlClass: Class, rootPackageName: string);
    addRelation(relation: RelationItem): void;
    addRelations(relations: RelationItem[]): void;
    getReferencedPackages(): Package[];
    writeToNode(node: CompositeGeneratorNode): void;
    writeOntologicalNatures(node: CompositeGeneratorNode): void;
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=ClassDeclarationItem.d.ts.map