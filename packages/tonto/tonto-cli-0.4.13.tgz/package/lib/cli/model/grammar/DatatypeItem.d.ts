import { CompositeGeneratorNode } from "langium/generate";
import { Class, Package } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
import { ClassDeclarationItem } from "./ClassDeclarationItem.js";
export type ClassDeclarationOrDatatypeItem = DataTypeItem | ClassDeclarationItem;
export declare class DataTypeItem extends ASTDeclarationItem {
    datatype: Class;
    rootPackageName: string;
    name: string;
    nameSlug: string;
    ontologicalNature?: string;
    specializations: ClassDeclarationOrDatatypeItem[];
    attributes: string[];
    constructor(ontoumlDatatype: Class);
    getReferencedPackages(): Package[];
    writeToNode(node: CompositeGeneratorNode): void;
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=DatatypeItem.d.ts.map