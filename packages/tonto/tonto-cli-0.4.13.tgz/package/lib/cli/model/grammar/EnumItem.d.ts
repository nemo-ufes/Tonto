import { CompositeGeneratorNode } from "langium/generate";
import { Class } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
export declare class EnumItem extends ASTDeclarationItem {
    name: string;
    nameSlug: string;
    elements: string[];
    constructor(ontoumlDatatype: Class);
    writeToNode(node: CompositeGeneratorNode): void;
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=EnumItem.d.ts.map