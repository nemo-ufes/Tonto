import { CompositeGeneratorNode } from "langium/generate";
import { GeneralizationSet, Package } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
export declare class GenSetItem extends ASTDeclarationItem {
    genset: GeneralizationSet;
    rootPackageName: string;
    name: string;
    nameSlug: string;
    generalItem?: string;
    categorizer?: string;
    specificItems?: string[];
    constructor(genset: GeneralizationSet);
    getReferencedPackages(): Package[];
    writeToNode(node: CompositeGeneratorNode): void;
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=GensetItem.d.ts.map