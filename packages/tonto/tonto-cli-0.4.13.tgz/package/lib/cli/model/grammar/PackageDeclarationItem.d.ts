import { CompositeGeneratorNode } from "langium/generate";
import { Package } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
import { ClassDeclarationItem } from "./ClassDeclarationItem.js";
import { ClassDeclarationOrDatatypeItem, DataTypeItem } from "./DatatypeItem.js";
import { EnumItem } from "./EnumItem.js";
import { GenSetItem } from "./GensetItem.js";
import { RelationItem } from "./RelationItem.js";
export declare class PackageDeclarationItem extends ASTDeclarationItem {
    ontoumlPackage: Package;
    isGlobal: boolean;
    name: string;
    nameSlug: string;
    imports: Map<string, Package>;
    packages: PackageDeclarationItem[];
    classDeclarations: ClassDeclarationOrDatatypeItem[];
    datatypes: DataTypeItem[];
    enumerations: EnumItem[];
    genSets: GenSetItem[];
    dir: string;
    relations: RelationItem[];
    constructor(ontoumlPackage: Package, dir: string);
    getInternalPackages(): PackageDeclarationItem[];
    getImports(): void;
    getClasses(): ClassDeclarationItem[];
    getDatatypes(): DataTypeItem[];
    getEnumerations(): EnumItem[];
    getGensets(): GenSetItem[];
    getRelations(): RelationItem[];
    addRelationsToClasses(relations: RelationItem[]): void;
    writePackage(): void;
    writeToNode(node: CompositeGeneratorNode): void;
    getElementNames(): string[];
    getNumberOfInternalElements(): number;
}
//# sourceMappingURL=PackageDeclarationItem.d.ts.map