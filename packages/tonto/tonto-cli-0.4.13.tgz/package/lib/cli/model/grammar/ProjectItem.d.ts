import { Package, Project } from "ontouml-js";
import { TontoManifest } from "../grammar/TontoManifest.js";
import { PackageDeclarationItem } from "./PackageDeclarationItem.js";
/**
 * Tonto Project element is the main object of the whole project. It contains
 * every package declaration and TontoManifest file
 *
 */
export declare class TontoProject {
    ontoumlProject: Project;
    packages: PackageDeclarationItem[];
    packageTable: Package[];
    projectName: string;
    projectSlug: string;
    manifest?: TontoManifest;
    workingDir: string;
    generationPath: string;
    constructor(ontoumlProject: Project, workingDir: string, outDir: string);
    startPackages(): void;
    writeProject(dir: string): void;
}
//# sourceMappingURL=ProjectItem.d.ts.map