import { CompositeGeneratorNode } from "langium/generate";
import { Package, Property, Relation } from "ontouml-js";
import { ASTDeclarationItem } from "./AstDeclarationItem.js";
import { CardinalityItem } from "./CardinalityItem.js";
declare enum RelationType {
    association = 0,
    aggregation = 1,
    composition = 2
}
export declare class RelationItem extends ASTDeclarationItem {
    relation: Relation;
    stereotype: string;
    firstEnd: Property | undefined;
    firstEndMetaAttributes: string[];
    firstCardinality: CardinalityItem;
    name: string | undefined;
    external: boolean;
    secondCardinality: CardinalityItem;
    secondEnd: Property | undefined;
    secondEndMetaAttributes: string[];
    relationType?: RelationType;
    specializations: string[];
    inverseOf: string[];
    constructor(relation: Relation, external?: boolean);
    getReferencedPackages(): Package[];
    /**
     * Write to Node Methods
     * @param node
     */
    writeToNode(node: CompositeGeneratorNode): void;
    private writeStereotype;
    private writeTypeAndName;
    private writeTargetElement;
    getNumberOfInternalElements(): number;
}
export {};
//# sourceMappingURL=RelationItem.d.ts.map