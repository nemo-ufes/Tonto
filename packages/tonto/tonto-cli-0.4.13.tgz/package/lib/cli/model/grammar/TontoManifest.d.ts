export interface TontoManifest {
    projectName: string;
    displayName: string;
    description?: string;
    publisher: string;
    version: string;
    license: string;
    dependencies: {
        [key: string]: TontoDependency;
    };
    outFolder: string;
    authors: Author[];
}
export interface Author {
    name: string;
    email?: string;
    url?: string;
}
export interface TontoDependencies {
    [name: string]: TontoDependency;
}
export interface TontoDependency {
    url: string;
    version?: string;
    directory?: string;
    branch?: string;
}
export declare const manifestFileName = "tonto.json";
export declare function toJson(manifest: TontoManifest): string;
export declare function createDefaultTontoManifest(): TontoManifest;
//# sourceMappingURL=TontoManifest.d.ts.map