import { Project } from "ontouml-js";
export interface GufoResultResponse {
    id?: string;
    status?: number;
    result: string;
}
export interface GufoErrorInfo {
    code?: string;
    description?: string;
    severity?: string;
    title?: string;
}
export interface ErrorGufoResultResponse {
    id?: string;
    message?: string;
    status?: number;
    info: GufoErrorInfo[];
}
export declare function createGufoErrorResponse(message: string, options?: {
    error?: unknown;
    info?: GufoErrorInfo[];
    status?: number;
}): ErrorGufoResultResponse;
export declare function formatGufoErrorMessage(error: Partial<ErrorGufoResultResponse> | undefined): string;
export declare function validateProjectForGufoTransform(project: Project): GufoErrorInfo[];
export declare function TransformTontoToGufo(project: Project): Promise<GufoResultResponse | ErrorGufoResultResponse>;
//# sourceMappingURL=gufoTransform.d.ts.map