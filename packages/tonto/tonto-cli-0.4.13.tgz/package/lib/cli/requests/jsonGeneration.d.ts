import { AstNode, LangiumDocument, LangiumDocuments } from "langium";
import { Diagnostic } from "vscode-languageserver-types";
export declare const JSON_GENERATION_STEPS: {
    readonly manifestLoading: "manifest loading";
    readonly sourceLoading: "source loading";
    readonly documentValidation: "document validation";
    readonly projectCreation: "project creation";
    readonly classGeneration: "class generation";
    readonly attributeGeneration: "attribute generation";
    readonly relationGeneration: "relation generation";
    readonly generalizationSetGeneration: "generalization set generation";
    readonly specializationGeneration: "specialization generation";
    readonly instantiationGeneration: "instantiation generation";
    readonly serialization: "serialization";
    readonly fileWriting: "file writing";
};
export type JsonGenerationStep = (typeof JSON_GENERATION_STEPS)[keyof typeof JSON_GENERATION_STEPS];
export type JsonGenerationErrorInfo = {
    code?: string;
    title: string;
    description: string;
    severity: "error";
    filePath?: string;
    line?: number;
    column?: number;
};
type CreateJsonGenerationErrorOptions = {
    error?: unknown;
    info?: JsonGenerationErrorInfo[];
    step: JsonGenerationStep;
};
export declare class JsonGenerationError extends Error {
    readonly cause?: unknown;
    readonly info: JsonGenerationErrorInfo[];
    readonly step: JsonGenerationStep;
    constructor(message: string, step: JsonGenerationStep, info: JsonGenerationErrorInfo[], cause?: unknown);
}
export declare function isJsonGenerationError(value: unknown): value is JsonGenerationError;
export declare function createJsonGenerationError(message: string, options: CreateJsonGenerationErrorOptions): JsonGenerationError;
export declare function normalizeJsonGenerationError(error: unknown, message: string, step: JsonGenerationStep, info?: JsonGenerationErrorInfo[]): JsonGenerationError;
export declare function createJsonGenerationNodeInfo(node: AstNode, options: Omit<JsonGenerationErrorInfo, "severity" | "filePath" | "line" | "column">): JsonGenerationErrorInfo;
export declare function getJsonGenerationDiagnosticInfo(document: LangiumDocument, diagnostic: Diagnostic): JsonGenerationErrorInfo;
export declare function getJsonGenerationDiagnosticInfos(document: LangiumDocument): JsonGenerationErrorInfo[];
export declare function getJsonGenerationDocumentErrorInfos(documents: LangiumDocuments): JsonGenerationErrorInfo[];
export declare function getJsonGenerationDocumentBlockingErrorInfos(documents: LangiumDocuments): JsonGenerationErrorInfo[];
export declare function getJsonGenerationBlockingDiagnosticInfos(document: LangiumDocument): JsonGenerationErrorInfo[];
export declare function formatJsonGenerationErrorMessage(error: unknown): string;
export {};
//# sourceMappingURL=jsonGeneration.d.ts.map