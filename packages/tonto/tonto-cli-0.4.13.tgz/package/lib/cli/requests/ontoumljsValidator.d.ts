import { Project } from "ontouml-js";
export interface ResultResponse {
    code?: string;
    data?: {
        source?: {
            id?: string;
            description?: string;
            stereotype?: string;
            type?: string;
        };
    };
    description?: string;
    severity?: string;
    title?: string;
}
export interface ErrorResultResponse {
    id?: string;
    message?: string;
    status?: number;
    info: ErrorInfo[];
}
interface ErrorInfo {
    keyword?: string;
    message?: string;
    dataPath?: string;
    schemaPath?: string;
}
export interface ValidationReturn {
    result: ResultResponse[];
    numberOfErrors: number;
}
export declare function validateTontoFile(project: Project, locally: boolean): Promise<ValidationReturn | ErrorResultResponse>;
export {};
//# sourceMappingURL=ontoumljsValidator.d.ts.map