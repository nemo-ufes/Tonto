export declare const TONTO_GENERATION_STEPS: {
    readonly importing: "importing";
    readonly sourceLoading: "source loading";
    readonly sourceValidation: "source validation";
    readonly projectParsing: "project parsing";
    readonly packageGeneration: "package generation";
    readonly fileWriting: "file writing";
};
export type TontoGenerationStep = (typeof TONTO_GENERATION_STEPS)[keyof typeof TONTO_GENERATION_STEPS];
export type TontoGenerationErrorInfo = {
    code?: string;
    title: string;
    description: string;
    severity: "error";
    filePath?: string;
    line?: number;
    column?: number;
};
type CreateTontoGenerationErrorOptions = {
    error?: unknown;
    info?: TontoGenerationErrorInfo[];
    step: TontoGenerationStep;
};
export declare class TontoGenerationError extends Error {
    readonly cause?: unknown;
    readonly info: TontoGenerationErrorInfo[];
    readonly step: TontoGenerationStep;
    constructor(message: string, step: TontoGenerationStep, info: TontoGenerationErrorInfo[], cause?: unknown);
}
export declare function isTontoGenerationError(value: unknown): value is TontoGenerationError;
export declare function createTontoGenerationError(message: string, options: CreateTontoGenerationErrorOptions): TontoGenerationError;
export declare function normalizeTontoGenerationError(error: unknown, message: string, step: TontoGenerationStep, info?: TontoGenerationErrorInfo[]): TontoGenerationError;
export declare function formatTontoGenerationErrorMessage(error: unknown): string;
export {};
//# sourceMappingURL=tontoGeneration.d.ts.map