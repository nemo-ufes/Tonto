export type AgentGuidanceFile = {
    fileName: string;
    content: string;
};
export declare const agentFolderGuidanceFiles: readonly AgentGuidanceFile[];
//# sourceMappingURL=agent-guidance.d.ts.map