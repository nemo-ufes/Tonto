export declare const cursorHeader = "---\nalwaysApply: true\n---\n";
export declare const vscodeHeader = "---\napplyTo: \"src/**/*.tonto\"\n---\n";
//# sourceMappingURL=headers.d.ts.map