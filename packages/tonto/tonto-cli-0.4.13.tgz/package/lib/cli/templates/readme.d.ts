export declare const readmeTemplate = "# Welcome to your new Tonto project: {{projectName}}!\n\nThis is a sample project to help you get started with Tonto.\n";
//# sourceMappingURL=readme.d.ts.map