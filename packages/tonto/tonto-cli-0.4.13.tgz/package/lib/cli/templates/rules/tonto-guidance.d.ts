export declare const tontoGuidance: string;
//# sourceMappingURL=tonto-guidance.d.ts.map