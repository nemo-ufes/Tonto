export type TontoOntologySkillTemplateFile = {
    relativePath: string;
    content: string;
};
export declare const tontoOntologySkillTemplateFiles: readonly TontoOntologySkillTemplateFile[];
//# sourceMappingURL=tonto-ontology.d.ts.map