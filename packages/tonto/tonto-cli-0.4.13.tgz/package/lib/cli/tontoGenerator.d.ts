import { OntoumlElement } from "ontouml-js";
export declare function generateTontoFile(ontoumlElements: OntoumlElement[], filePath: string, destination: string | undefined): string;
interface FilePathData {
    destination: string;
    name: string;
}
export declare function customExtractDestinationAndName(filePath: string, destination: string | undefined): FilePathData;
export {};
//# sourceMappingURL=tontoGenerator.d.ts.map