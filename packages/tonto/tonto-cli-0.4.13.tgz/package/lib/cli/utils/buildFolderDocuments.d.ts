import { LangiumDocuments } from "langium";
import { Model } from "../../language/index.js";
import { TontoServices } from "../../language/tonto-module.js";
import { TontoManifest } from "../model/grammar/TontoManifest.js";
export interface BuiltFolderDocumentsResult {
    allFiles: string[];
    documents: LangiumDocuments;
    folderAbsolutePath: string;
    manifest: TontoManifest;
    models: Model[];
}
export interface BuildFolderDocumentsOptions {
    validation?: boolean;
    manifest?: TontoManifest;
}
export declare function getTontoProjectSourceFiles(dirName: string, manifest: TontoManifest): Promise<string[]>;
export declare function buildFolderDocuments(dirName: string, services: TontoServices, options?: BuildFolderDocumentsOptions): Promise<BuiltFolderDocumentsResult>;
//# sourceMappingURL=buildFolderDocuments.d.ts.map