import { OntoumlElement } from "ontouml-js";
export declare const getNearestParentPackage: (ontoumlElement: OntoumlElement | undefined) => OntoumlElement | undefined;
//# sourceMappingURL=getParentPackage.d.ts.map