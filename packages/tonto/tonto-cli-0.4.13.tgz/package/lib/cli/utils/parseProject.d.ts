import { Project } from "ontouml-js";
import { Model } from "../../language/index.js";
export interface ParseProjectContext {
    model: Model;
    name: string;
}
export declare function parseProject(ctx: ParseProjectContext): Project;
//# sourceMappingURL=parseProject.d.ts.map