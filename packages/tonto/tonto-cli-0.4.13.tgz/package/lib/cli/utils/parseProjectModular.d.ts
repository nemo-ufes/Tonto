import { CompositeGeneratorNode } from "langium/generate";
import { Project } from "ontouml-js";
import { Model } from "../../language/index.js";
import { TontoManifest } from "../model/grammar/TontoManifest.js";
export interface ModularGeneratorContext {
    models: Model[];
    manifest: TontoManifest;
    fileNode: CompositeGeneratorNode;
    folderAbsolutePath: string;
    label?: string;
    description?: string;
}
export declare function parseProjectModular(ctx: ModularGeneratorContext): Project;
//# sourceMappingURL=parseProjectModular.d.ts.map