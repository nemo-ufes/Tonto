import { Project } from "ontouml-js";
export declare function parseSerializedProject(serializedProject: string): Project;
//# sourceMappingURL=parseSerializedProject.d.ts.map