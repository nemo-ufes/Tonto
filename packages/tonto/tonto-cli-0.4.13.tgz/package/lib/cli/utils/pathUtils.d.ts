export declare function getTemplatesPath(): string;
//# sourceMappingURL=pathUtils.d.ts.map