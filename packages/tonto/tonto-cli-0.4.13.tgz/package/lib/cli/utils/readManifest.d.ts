import { TontoManifest } from "../model/grammar/TontoManifest.js";
export declare function readTontoManifest(dirName: string): TontoManifest | undefined;
export declare function readOrCreateDefaultTontoManifest(dirName: string): TontoManifest;
//# sourceMappingURL=readManifest.d.ts.map