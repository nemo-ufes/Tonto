export declare function replaceWhitespace(word: string | undefined): string;
export declare function formatForId(word: string | undefined, withKeywords?: boolean): string;
//# sourceMappingURL=replaceWhitespace.d.ts.map