import { Project } from "ontouml-js";
export declare function serializeProject(project: Project): string;
//# sourceMappingURL=serializeProject.d.ts.map