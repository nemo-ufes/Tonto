import { ModelElement } from "ontouml-js";
export declare const TONTO_SOURCE_NAME_PROPERTY = "__tontoName";
export declare const TONTO_SOURCE_IMPORTS_PROPERTY = "__tontoImports";
type PropertyAssignmentCarrier = {
    propertyAssignments?: object | null;
};
export declare function setTontoSourceName(element: ModelElement, name: string): void;
export declare function getTontoSourceName(element: PropertyAssignmentCarrier | undefined): string | undefined;
export declare function setTontoSourceImports(element: ModelElement, imports: string[]): void;
export declare function getTontoSourceImports(element: PropertyAssignmentCarrier | undefined): string[];
export {};
//# sourceMappingURL=tontoMetadata.d.ts.map