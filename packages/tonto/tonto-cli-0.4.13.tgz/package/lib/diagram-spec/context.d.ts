import { ContextModule, Model } from "../language/generated/ast.js";
import { TontoDiagramWorkspaceContext } from "./types.js";
type DiagramWorkspace = {
    sourceModel?: Model;
    sourcePath?: string;
    projectRoot: string;
    models: Model[];
};
export declare function loadTontoDiagramProjectWorkspace(diagramPath: string): Promise<DiagramWorkspace>;
export declare function loadTontoDiagramWorkspace(source: string | undefined, diagramPath: string): Promise<DiagramWorkspace>;
export declare function collectTontoDiagramWorkspaceContext(source: string | undefined, diagramPath: string): Promise<TontoDiagramWorkspaceContext>;
export declare function buildTontoDiagramWorkspaceContext(models: Model[], sourcePath: string): TontoDiagramWorkspaceContext;
export declare function resolveRequestedPackages(models: Model[], requestedPackages: string[]): {
    missing: string[];
    packages: ContextModule[];
};
export declare function resolveTontoDiagramSourcePath(source: string, diagramPath: string): string;
export {};
//# sourceMappingURL=context.d.ts.map