import { TontoDiagramParseResult } from "./types.js";
export declare function parseTontoDiagramSpec(sourceText: string): TontoDiagramParseResult;
//# sourceMappingURL=parser.d.ts.map