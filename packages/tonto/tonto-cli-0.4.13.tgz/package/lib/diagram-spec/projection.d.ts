import { resolveTontoDiagramSourcePath } from "./context.js";
import { TontoDiagramGraph, TontoDiagramSpec } from "./types.js";
export declare function buildTontoDiagramGraph(spec: TontoDiagramSpec, diagramPath: string): Promise<TontoDiagramGraph>;
export { resolveTontoDiagramSourcePath as resolveDiagramSourcePath };
//# sourceMappingURL=projection.d.ts.map