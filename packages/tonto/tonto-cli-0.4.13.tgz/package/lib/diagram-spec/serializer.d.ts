import { TontoDiagramSpec } from "./types.js";
export declare function serializeTontoDiagramSpec(spec: TontoDiagramSpec): string;
/**
 * Replace `spec.relations` so the file reflects the supplied set of edge ids.
 * Used by the extension after each spec mutation to keep the diagram source
 * in sync with the rendered relation set (auto-add).
 */
export declare function syncTontoDiagramRelations(spec: TontoDiagramSpec, edgeIds: string[]): TontoDiagramSpec;
export declare function updateTontoDiagramLayout(spec: TontoDiagramSpec, layouts: Array<{
    target: string;
    x: number;
    y: number;
}>): TontoDiagramSpec;
//# sourceMappingURL=serializer.d.ts.map