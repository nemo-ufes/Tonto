import { GeneratorContext } from "langium-sprotty";
import { SEdge } from "sprotty-protocol";
import { ElementRelation, Model } from "../generated/ast.js";
export declare function generateEdge(relation: ElementRelation, { idCache }: GeneratorContext<Model>): SEdge;
//# sourceMappingURL=generate-edge.d.ts.map