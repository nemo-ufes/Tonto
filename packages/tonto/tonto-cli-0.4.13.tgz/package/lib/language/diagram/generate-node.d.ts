import { GeneratorContext } from "langium-sprotty";
import { SNode } from "sprotty-protocol";
import { DataTypeOrClassOrRelation, Model } from "../generated/ast.js";
export declare function generateNode(classDeclaration: DataTypeOrClassOrRelation, context: GeneratorContext<Model>): SNode | undefined;
//# sourceMappingURL=generate-node.d.ts.map