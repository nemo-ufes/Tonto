/********************************************************************************
 * Copyright (c) 2021 TypeFox and others.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the Eclipse
 * Public License v. 2.0 are satisfied: GNU General Public License, version 2
 * with the GNU Classpath Exception which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 ********************************************************************************/
import { LayoutOptions } from "elkjs";
import { DefaultLayoutConfigurator } from "sprotty-elk/lib/elk-layout.js";
import { SGraph, SModelIndex, SNode, SPort } from "sprotty-protocol";
export declare class TontoLayoutConfigurator extends DefaultLayoutConfigurator {
    direction: "UP" | "DOWN" | "LEFT" | "RIGHT";
    setDirection(direction: "UP" | "DOWN" | "LEFT" | "RIGHT"): void;
    protected graphOptions(sgraph: SGraph, index: SModelIndex): LayoutOptions;
    protected nodeOptions(snode: SNode, index: SModelIndex): LayoutOptions;
    protected portOptions(sport: SPort, index: SModelIndex): LayoutOptions;
}
//# sourceMappingURL=layout-config.d.ts.map