import { GeneratorContext, LangiumDiagramGenerator, LangiumDiagramGeneratorArguments } from "langium-sprotty";
import { SEdge, SModelRoot, SNode } from "sprotty-protocol";
import { ClassDeclaration, ContextModule, DataTypeOrClassOrRelation, Model } from "../generated/ast.js";
export declare class TontoDiagramGenerator extends LangiumDiagramGenerator {
    showExternalDiagrams: boolean;
    generate(args: LangiumDiagramGeneratorArguments): Promise<SModelRoot>;
    protected generateRoot(args: GeneratorContext<Model>): SModelRoot;
    protected generateSpecialization(sourceClass: ClassDeclaration, targetClass: ClassDeclaration, { idCache }: GeneratorContext<Model>): SEdge;
    protected generateExternalPackages(args: GeneratorContext<Model>, elements: Map<ContextModule, DataTypeOrClassOrRelation[]>): SNode[];
}
//# sourceMappingURL=tonto-diagram.d.ts.map