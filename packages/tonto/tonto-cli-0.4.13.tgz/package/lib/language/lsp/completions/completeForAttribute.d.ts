import { CompletionAcceptor, CompletionContext, NextFeature } from "langium/lsp";
export declare function completeForAttributeSnippets(context: CompletionContext, next: NextFeature, acceptor: CompletionAcceptor): void;
//# sourceMappingURL=completeForAttribute.d.ts.map