import { CompletionAcceptor, CompletionContext } from "langium/lsp";
declare function completeForCardinality(context: CompletionContext, acceptor: CompletionAcceptor): void;
export { completeForCardinality };
//# sourceMappingURL=completeForCardinality.d.ts.map