import { CompletionAcceptor, CompletionContext, NextFeature } from "langium/lsp";
declare function completeForDataType(context: CompletionContext, next: NextFeature, acceptor: CompletionAcceptor): void;
export { completeForDataType };
//# sourceMappingURL=completeForDatatype.d.ts.map