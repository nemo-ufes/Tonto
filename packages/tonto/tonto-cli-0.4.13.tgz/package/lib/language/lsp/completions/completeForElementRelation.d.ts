import { CompletionAcceptor, CompletionContext, NextFeature } from "langium/lsp";
declare function completeForElementRelation(context: CompletionContext, keyword: NextFeature, acceptor: CompletionAcceptor): void;
export { completeForElementRelation };
//# sourceMappingURL=completeForElementRelation.d.ts.map