import { CompletionAcceptor, CompletionContext, NextFeature } from "langium/lsp";
declare function completeForEnumSnippets(context: CompletionContext, next: NextFeature, acceptor: CompletionAcceptor): void;
export { completeForEnumSnippets };
//# sourceMappingURL=completeForEnumSnippets.d.ts.map