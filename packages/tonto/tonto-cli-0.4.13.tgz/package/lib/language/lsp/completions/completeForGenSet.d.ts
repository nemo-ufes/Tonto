import { CompletionAcceptor, CompletionContext, NextFeature } from "langium/lsp";
declare function completeForGenSetSnippets(context: CompletionContext, next: NextFeature, acceptor: CompletionAcceptor): void;
export { completeForGenSetSnippets };
//# sourceMappingURL=completeForGenSet.d.ts.map