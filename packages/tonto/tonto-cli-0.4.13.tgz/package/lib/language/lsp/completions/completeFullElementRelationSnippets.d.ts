import { CompletionAcceptor, CompletionContext } from "langium/lsp";
export declare function completeFullElementRelationSnippets(context: CompletionContext, acceptor: CompletionAcceptor): void;
export declare function completeFullExternalElementRelationSnippets(context: CompletionContext, acceptor: CompletionAcceptor): void;
//# sourceMappingURL=completeFullElementRelationSnippets.d.ts.map