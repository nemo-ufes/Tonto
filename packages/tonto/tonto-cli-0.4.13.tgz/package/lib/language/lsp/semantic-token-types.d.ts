import { SemanticTokensOptions } from "vscode-languageserver";
export declare const TontoSemanticTokenTypes: Record<string, number>;
export declare const AllSemanticTokenModifiers: Record<string, number>;
export declare const TontoSemanticTokenOptions: SemanticTokensOptions;
//# sourceMappingURL=semantic-token-types.d.ts.map