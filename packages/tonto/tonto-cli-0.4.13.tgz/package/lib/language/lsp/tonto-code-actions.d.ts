import { LangiumDocument, MaybePromise } from "langium";
import { CodeActionProvider } from "langium/lsp";
import { CodeActionParams } from "vscode-languageserver-protocol";
import { CodeAction, Command } from "vscode-languageserver-types";
export declare class TontoActionProvider implements CodeActionProvider {
    getCodeActions(document: LangiumDocument, params: CodeActionParams): MaybePromise<Array<Command | CodeAction>>;
    private createCodeAction;
    private makeUpperCase;
}
//# sourceMappingURL=tonto-code-actions.d.ts.map