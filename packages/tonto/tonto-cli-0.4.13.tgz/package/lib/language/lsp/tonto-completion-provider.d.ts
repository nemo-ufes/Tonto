import { MaybePromise } from "langium";
import { CompletionAcceptor, CompletionContext, DefaultCompletionProvider, NextFeature } from "langium/lsp";
export declare class TontoCompletionProvider extends DefaultCompletionProvider {
    protected completionFor(context: CompletionContext, next: NextFeature, acceptor: CompletionAcceptor): MaybePromise<void>;
    private isInternalRelation;
    private isExternalRelation;
}
//# sourceMappingURL=tonto-completion-provider.d.ts.map