export {};
//# sourceMappingURL=tonto-definition-provider.d.ts.map