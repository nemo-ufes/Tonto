import { JSDocDocumentationProvider } from "langium";
import { TontoServices } from "../tonto-module.js";
export declare class TontoDocumentationProvider extends JSDocDocumentationProvider {
    constructor(services: TontoServices);
}
//# sourceMappingURL=tonto-document-hover-provider.d.ts.map