export {};
//# sourceMappingURL=tonto-highlight-provider.d.ts.map