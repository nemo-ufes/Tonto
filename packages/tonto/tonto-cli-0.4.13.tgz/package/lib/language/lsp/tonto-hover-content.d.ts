import { ClassDeclaration, OntologicalNature as ASTNature } from "../generated/ast.js";
import { TontoNatures } from "../models/OntologicalCategory.js";
type NatureProviderSource = "stereotype" | "ontological-natures";
export interface NatureResolutionTrace {
    declaredNatures?: ASTNature[];
    nature: TontoNatures;
    path: string[];
    providerName: string;
    providerSource: NatureProviderSource;
    providerStereotype: string;
}
export interface ClassHoverInfo {
    derivationExplanation: string;
    nature: TontoNatures;
    primaryTrace?: NatureResolutionTrace;
    stereotype: string;
    stereotypeExplanation: string;
    traces: NatureResolutionTrace[];
}
export declare function getClassHoverInfo(node: ClassDeclaration): ClassHoverInfo;
export declare function buildClassDeclarationHoverMarkdown(node: ClassDeclaration): string;
export {};
//# sourceMappingURL=tonto-hover-content.d.ts.map