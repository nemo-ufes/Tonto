import { AstNode, MaybePromise } from "langium";
import { AstNodeHoverProvider } from "langium/lsp";
import { Hover } from "vscode-languageserver";
import { TontoServices } from "../tonto-module.js";
export declare class TontoHoverProvider extends AstNodeHoverProvider {
    constructor(services: TontoServices);
    protected getAstNodeHoverContent(node: AstNode): MaybePromise<Hover | undefined>;
}
//# sourceMappingURL=tonto-hover-provider.d.ts.map