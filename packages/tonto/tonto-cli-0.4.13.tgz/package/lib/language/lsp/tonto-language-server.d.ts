import { DefaultLanguageServer } from "langium/lsp";
import { InitializeParams, InitializeResult, InitializedParams } from "vscode-languageserver";
export declare class TontoLanguageServer extends DefaultLanguageServer {
    protected buildInitializeResult(_params: InitializeParams): InitializeResult<any>;
    protected fireInitializedOnDefaultServices(params: InitializedParams): void;
}
//# sourceMappingURL=tonto-language-server.d.ts.map