import { LangiumParserErrorMessageProvider } from "langium";
export declare class TontoParserErrorMessageProvider extends LangiumParserErrorMessageProvider {
}
//# sourceMappingURL=tonto-parser-error-message-provider.ts.d.ts.map