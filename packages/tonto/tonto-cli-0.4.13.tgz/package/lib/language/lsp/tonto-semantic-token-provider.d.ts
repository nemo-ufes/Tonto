import { AstNode } from "langium";
import { AbstractSemanticTokenProvider, SemanticTokenAcceptor, SemanticTokenRangeOptions } from "langium/lsp";
import * as ast from "../generated/ast.js";
export declare class TontoSemanticTokenProvider extends AbstractSemanticTokenProvider {
    protected highlightToken(options: SemanticTokenRangeOptions): void;
    protected highlightElement(node: AstNode, acceptor: SemanticTokenAcceptor): void;
    datatypeTokens(node: ast.DataType, acceptor: SemanticTokenAcceptor): void;
    private contextModuleTokens;
    private classElementTokens;
    private ontologicalCategoryTokens;
    private elementRelationTokens;
    private relationMetaAttributesTokens;
    private relationMetaAttributeTokens;
    private enumTokens;
    private enumElementTokens;
    private generalizationSetTokens;
}
//# sourceMappingURL=tonto-semantic-token-provider.d.ts.map