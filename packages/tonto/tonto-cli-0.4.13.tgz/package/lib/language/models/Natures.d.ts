import { OntologicalNature } from "ontouml-js";
import { ClassDeclaration, OntologicalNature as ASTNature } from "../generated/ast.js";
declare function getNatureFromAst(nature: ASTNature): OntologicalNature[];
declare function getAstNatureFromOntoumljs(nature: OntologicalNature): string;
declare function getNatureFromUltimateSortal(classDeclaration: ClassDeclaration): OntologicalNature | undefined;
declare function getDefaultNatureFromNonSortal(classDeclaration: ClassDeclaration): OntologicalNature[];
export declare const tontoNatureUtils: {
    getNatureFromAst: typeof getNatureFromAst;
    getNatureFromUltimateSortal: typeof getNatureFromUltimateSortal;
    getDefaultNatureFromNonSortal: typeof getDefaultNatureFromNonSortal;
    getAstNatureFromOntoumljs: typeof getAstNatureFromOntoumljs;
};
export {};
//# sourceMappingURL=Natures.d.ts.map