declare enum OntologicalCategoryEnum {
    CLASS = "class",
    TYPE = "type",
    HISTORICAL_ROLE = "historicalRole",
    HISTORICAL_ROLE_MIXIN = "historicalRoleMixin",
    EVENT = "event",
    SITUATION = "situation",
    CATEGORY = "category",
    MIXIN = "mixin",
    ROLE_MIXIN = "roleMixin",
    PHASE_MIXIN = "phaseMixin",
    KIND = "kind",
    COLLECTIVE = "collective",
    QUANTITY = "quantity",
    RELATOR = "relator",
    QUALITY = "quality",
    MODE = "mode",
    INTRINSIC_MODE = "intrinsicMode",
    EXTRINSIC_MODE = "extrinsicMode",
    SUBKIND = "subkind",
    ROLE = "role",
    PHASE = "phase",
    ENUMERATION = "enumeration",
    DATATYPE = "datatype",
    ABSTRACT = "abstract"
}
export type TontoNatures = "objects" | "functional-complexes" | "collectives" | "quantities" | "relators" | "modes" | "qualities" | "events" | "situations" | "types" | "abstract-individuals" | "none";
declare const UltimateSortalOntoCategories: OntologicalCategoryEnum[];
declare const BaseSortalOntoCategories: OntologicalCategoryEnum[];
declare const SortalOntoCategories: OntologicalCategoryEnum[];
declare function isSortalOntoCategory(stereotype: string): boolean;
declare function isUltimateSortalOntoCategory(stereotype: string): boolean;
declare function isBaseSortalOntoCategory(stereotype: string): boolean;
declare function isNonSortalOntoCategory(stereotype: string): boolean;
declare function getOntologicalCategory(stereotype: string): OntologicalCategoryEnum | undefined;
export { BaseSortalOntoCategories, OntologicalCategoryEnum, SortalOntoCategories, UltimateSortalOntoCategories, getOntologicalCategory, isBaseSortalOntoCategory, isNonSortalOntoCategory, isSortalOntoCategory, isUltimateSortalOntoCategory };
//# sourceMappingURL=OntologicalCategory.d.ts.map