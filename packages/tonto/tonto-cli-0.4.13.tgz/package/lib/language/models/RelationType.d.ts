export declare enum RelationTypes {
    MATERIAL = "material",
    DERIVATION = "derivation",
    COMPARATIVE = "comparative",
    MEDIATION = "mediation",
    CHARACTERIZATION = "characterization",
    EXTERNAL_DEPENDENCE = "externalDependence",
    COMPONENT_OF = "componentOf",
    MEMBER_OF = "memberOf",
    SUBCOLLECTION_OF = "subCollectionOf",
    SUBQUANTITY_OF = "subQuantityOf",
    INSTANTIATION = "instantiation",
    TERMINATION = "termination",
    PARTICIPATIONAL = "participational",
    PARTICIPATION = "participation",
    HISTORICAL_DEPENDENCE = "historicalDependence",
    CREATION = "creation",
    MANIFESTATION = "manifestation",
    BRINGS_ABOUT = "bringsAbout",
    TRIGGERS = "triggers"
}
//# sourceMappingURL=RelationType.d.ts.map