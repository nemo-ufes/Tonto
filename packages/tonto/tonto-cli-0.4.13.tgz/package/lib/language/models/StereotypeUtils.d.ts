import { ClassStereotype, OntologicalNature } from "ontouml-js";
import { OntologicalCategoryEnum } from "./OntologicalCategory.js";
type AllowedStereotypes = {
    [key in OntologicalCategoryEnum]: OntologicalNature[];
};
declare const allowedStereotypeRestrictedToMatches: AllowedStereotypes;
declare function hasSortalStereotype(stereotype: string): boolean;
declare function hasNonSortalStereotype(stereotype: string): boolean;
declare function isRigidStereotype(stereotype: string): boolean;
declare function isSemiRigidStereotype(stereotype: string): boolean;
declare function isAntiRigidStereotype(stereotype: string): boolean;
declare function getClassStereotype(stereotype: string): ClassStereotype | undefined;
export { allowedStereotypeRestrictedToMatches, hasSortalStereotype, hasNonSortalStereotype, getClassStereotype, isRigidStereotype, isAntiRigidStereotype, isSemiRigidStereotype, };
//# sourceMappingURL=StereotypeUtils.d.ts.map