import { AstNode, DefaultNameProvider } from "langium";
import { ClassDeclaration, ContextModule } from "../generated/ast.js";
export declare function toQualifiedName(pack: ContextModule | ClassDeclaration, childName: string): string;
export declare class TontoQualifiedNameProvider extends DefaultNameProvider {
    /**
   * @param qualifier if the qualifier is a `string`, simple string concatenation is done: `qualifier.name`.
   *      if the qualifier is a `Package` fully qualified name is created: `package1.package2.name`.
   * @param name simple name
   * @returns qualified name separated by `.`
   */
    getQualifiedName(node: AstNode): string | undefined;
    getName(node: AstNode): string | undefined;
}
//# sourceMappingURL=tonto-name-provider.d.ts.map