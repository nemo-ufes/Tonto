import { AstNode, AstNodeDescription, DefaultScopeComputation, LangiumDocument, PrecomputedScopes } from "langium";
import { CancellationToken } from "vscode-jsonrpc";
import { TontoServices } from "../tonto-module.js";
export declare class TontoScopeComputation extends DefaultScopeComputation {
    private readonly qualifiedNameProvider;
    constructor(services: TontoServices);
    /**
     * Publishes globally visible symbols for the current document.
     *
     * Non-global context modules are exported so `import package.name` can resolve.
     * Declarations inside global context modules are exported by both simple and
     * qualified names so they remain accessible without imports.
     */
    computeExports(document: LangiumDocument, cancelToken?: CancellationToken): Promise<AstNodeDescription[]>;
    /**
     * Precomputes the symbols visible from the current document.
     *
     * Imported context modules are processed first so their declarations become
     * visible at the primary context module level alongside local declarations.
     */
    computeLocalScopes(document: LangiumDocument<AstNode>, cancelToken?: CancellationToken): Promise<PrecomputedScopes>;
    protected exportNode(node: AstNode, exports: AstNodeDescription[], document: LangiumDocument): void;
    private processContainer;
    private processDeclaration;
    private addRelationDescriptions;
    private addRelationEndDescriptions;
    private addRelationEndDescription;
    private addSimpleAndQualifiedDescriptions;
    private addDescription;
    private getLegacyQualifiedRelationName;
    private findOwningContextModule;
    private isGlobalContextModuleDeclaration;
    private isLocalScopeDeclaration;
}
//# sourceMappingURL=tonto-scope-computation.d.ts.map