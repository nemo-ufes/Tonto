import { AstNodeDescription, DefaultScopeProvider, ReferenceInfo, Scope, ScopeOptions } from "langium";
/**
 * Resolves both local and global symbols case-insensitively.
 *
 * Tonto treats symbol lookup the same regardless of where the symbol comes from,
 * so the case-insensitive flag must be applied when layering local scopes and
 * when consulting the shared global index.
 */
export declare class TontoScopeProvider extends DefaultScopeProvider {
    protected createScope(elements: Iterable<AstNodeDescription>, outerScope?: Scope, options?: ScopeOptions): Scope;
    protected getGlobalScope(referenceType: string, _context: ReferenceInfo): Scope;
}
//# sourceMappingURL=tonto-scope-provider.d.ts.map