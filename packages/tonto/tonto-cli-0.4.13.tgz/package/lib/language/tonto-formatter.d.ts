import { AstNode } from "langium";
import { AbstractFormatter } from "langium/lsp";
export declare class TontoFormatter extends AbstractFormatter {
    protected format(node: AstNode): void;
}
//# sourceMappingURL=tonto-formatter.d.ts.map