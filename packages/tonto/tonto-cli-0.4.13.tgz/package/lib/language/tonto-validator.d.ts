import { ValidationRegistry } from "langium";
import type { TontoServices } from "./tonto-module.js";
/**
 * Registry for validation checks.
 */
export declare class TontoValidationRegistry extends ValidationRegistry {
    constructor(services: TontoServices);
}
//# sourceMappingURL=tonto-validator.d.ts.map