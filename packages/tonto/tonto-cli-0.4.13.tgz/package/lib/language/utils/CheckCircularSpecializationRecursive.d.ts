import { ValidationAcceptor } from "langium";
import { ClassDeclaration, GeneralizationSet } from "../generated/ast.js";
declare const checkCircularSpecializationRecursive: (actualElement: ClassDeclaration, verificationList: ClassDeclaration[], accept: ValidationAcceptor) => void;
declare const checkCircularSpecializationRecursiveWithGenset: (actualElement: ClassDeclaration | GeneralizationSet, verificationList: ClassDeclaration[], genSets: GeneralizationSet[], accept: ValidationAcceptor) => void;
export { checkCircularSpecializationRecursive, checkCircularSpecializationRecursiveWithGenset };
//# sourceMappingURL=CheckCircularSpecializationRecursive.d.ts.map