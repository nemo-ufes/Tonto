import { ValidationAcceptor } from "langium";
import { ClassDeclaration, GeneralizationSet } from "../generated/ast.js";
declare const validateSortalSpecializesUniqueUltimateSortalRecursive: (actualElement: ClassDeclaration, UltimateSortalSpecializedSet: Set<string>, accept: ValidationAcceptor) => void;
declare const checkSortalSpecializesUniqueUltimateSortalRecursive: (actualElement: ClassDeclaration | GeneralizationSet, genSets: GeneralizationSet[], accept: ValidationAcceptor, UltimateSortalSpecializedSet: Set<string>, visitedElements?: Set<GeneralizationSet | ClassDeclaration>) => Set<string>;
export { checkSortalSpecializesUniqueUltimateSortalRecursive, validateSortalSpecializesUniqueUltimateSortalRecursive };
//# sourceMappingURL=CheckSortalSpecializesUniqueUltimateSortalRecursive.d.ts.map