import { ValidationAcceptor } from "langium";
import { ClassDeclaration } from "../generated/ast.js";
declare const checkUltimateSortalSpecializesUltimateSortalRecursive: (actualElement: ClassDeclaration, accept: ValidationAcceptor) => void;
export { checkUltimateSortalSpecializesUltimateSortalRecursive };
//# sourceMappingURL=CheckUltimateSortalSpecializesUltimateSortalRecursive.d.ts.map