import { OntologicalNature } from "../generated/ast.js";
declare function checkNatureCompatibleRestrictedTo(generalNature: OntologicalNature, specificNature: OntologicalNature): boolean;
export { checkNatureCompatibleRestrictedTo };
//# sourceMappingURL=checkNatureCompatibleRestrictedTo.d.ts.map