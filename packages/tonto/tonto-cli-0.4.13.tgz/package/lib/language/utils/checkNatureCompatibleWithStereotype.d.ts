import { NonSortal, OntologicalNature, Sortal, UltimateSortal } from "../generated/ast.js";
declare function checkNatureCompatibleWithStereotype(nature: OntologicalNature, stereotype: UltimateSortal | NonSortal | Sortal | undefined | string): boolean;
export { checkNatureCompatibleWithStereotype };
//# sourceMappingURL=checkNatureCompatibleWithStereotype.d.ts.map