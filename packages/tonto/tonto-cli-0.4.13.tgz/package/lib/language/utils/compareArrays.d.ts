import { OntologicalNature } from "ontouml-js";
export declare function compareArrays(array1: OntologicalNature[], array2: OntologicalNature[]): boolean;
export declare function compareArrayWithSet(array1: OntologicalNature[], set: Set<OntologicalNature>): boolean;
//# sourceMappingURL=compareArrays.d.ts.map