export declare function formPhrase(words: string[]): string;
//# sourceMappingURL=formPhrase.d.ts.map