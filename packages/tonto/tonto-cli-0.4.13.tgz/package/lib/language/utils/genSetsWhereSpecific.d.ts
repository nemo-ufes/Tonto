import { GeneralizationSet } from "../generated/ast.js";
export declare function getGensetsWhereSpecific(declaration: string, genSets: GeneralizationSet[]): GeneralizationSet[];
//# sourceMappingURL=genSetsWhereSpecific.d.ts.map