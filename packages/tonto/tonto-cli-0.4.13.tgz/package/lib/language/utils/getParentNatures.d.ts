import { OntologicalNature } from "ontouml-js";
import { ClassDeclaration, GeneralizationSet } from "../generated/ast.js";
declare const getParentNatures: (actualElement: ClassDeclaration | GeneralizationSet, natures: Set<OntologicalNature>, genSets: GeneralizationSet[], verifiedElements?: Array<ClassDeclaration | GeneralizationSet>) => Set<OntologicalNature>;
export { getParentNatures };
//# sourceMappingURL=getParentNatures.d.ts.map