export declare function isReservedKeyword(keyword: string): boolean;
//# sourceMappingURL=isReservedKeyword.d.ts.map