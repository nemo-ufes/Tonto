import { AstNode } from "langium";
import { ContextModule, Import, Model, Statement } from "../generated/ast.js";
export declare function getModelStatements(model: Model): Statement[];
export declare function getModelImports(model: Model): Import[];
export declare function getModelContextModules(model: Model): ContextModule[];
export declare function getPrimaryContextModule(model: Model): ContextModule | undefined;
export declare function getPrimaryContextModuleOrThrow(model: Model): ContextModule;
export declare function getOwningModel(node: AstNode): Model | undefined;
//# sourceMappingURL=modelStatements.d.ts.map