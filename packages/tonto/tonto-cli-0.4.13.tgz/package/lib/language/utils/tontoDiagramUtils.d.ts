import { ClassDeclaration, ContextModule, DataType, DataTypeOrClassOrRelation, ElementRelation } from "../generated/ast.js";
export type Specialization = {
    from: ClassDeclaration;
    to: ClassDeclaration;
};
export declare class TontoDiagramUtils {
    model: ContextModule;
    referencedModels: Map<ContextModule, DataTypeOrClassOrRelation[]>;
    constructor(model: ContextModule);
    getClassDeclarations(): ClassDeclaration[];
    getDatatypes(): DataType[];
    getRelations(withExternal: boolean): ElementRelation[];
    getSpecializations(withExternal: boolean): Specialization[];
    getReferencedClasses(): Map<ContextModule, DataTypeOrClassOrRelation[]>;
    protected addReferencedClasses(relation: ElementRelation, referencedModels: Map<ContextModule, DataTypeOrClassOrRelation[]>): void;
}
//# sourceMappingURL=tontoDiagramUtils.d.ts.map