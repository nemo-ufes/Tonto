import * as ast from "../generated/ast.js";
import { TontoNatures } from "../models/OntologicalCategory.js";
export type TontoNatureResult = {
    nature: TontoNatures;
    isKind: boolean;
};
declare function getSemanticTokenFromNature(nature: TontoNatureResult): string;
declare function getTontoNature(container: ast.ClassDeclaration): TontoNatureResult;
export declare const tontoNatureUtils: {
    getSemanticTokenFromNature: typeof getSemanticTokenFromNature;
    getTontoNature: typeof getTontoNature;
};
export {};
//# sourceMappingURL=tontoNatureUtils.d.ts.map