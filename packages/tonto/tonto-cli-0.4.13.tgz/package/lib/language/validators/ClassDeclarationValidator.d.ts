import { ValidationAcceptor } from "langium";
import { ClassDeclaration } from "../generated/ast.js";
export declare class ClassDeclarationValidator {
    /**
   * Check if the class declaration doesn't have a specific stereotype
   */
    checkClassWithoutStereotype(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
    /**
   * Verify if the class is an UltimateSortal and specializes another
   * UltimateSortal (stereotypes: kind, collective, quantity, relator, quality,
   * mode, intrinsicMode or extrinsicMode)
   */
    checkUltimateSortalSpecializeUltimateSortal(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
    /**
   * Verify if it is a generalization between two classes. Verify if the general
   * class has an Anti rigid stereotype and the specific class has a Rigid or
   * Anti Rigid stereotype
   */
    checkRigidSpecializesAntiRigid(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
    /**
   * Verify if there are duplicated declaration names
   */
    checkDuplicatedReferenceNames(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
    /**
   * Verify if the class is not restricted with an incompatible Nature with this
   * class stereotype.
   */
    checkCompatibleNatures(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
    /**
   * Verify if the class is specializing a Nature permitted by its general class
   */
    checkSpecializationOfCorrectNature(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
    /**
   * Verify if the general class is a Sortal stereotype and the specific class
   * has a non-Sortal stereotype. This generalization is forbidden
   */
    checkGeneralizationSortality(classDeclaration: ClassDeclaration, accept: ValidationAcceptor): void;
}
//# sourceMappingURL=ClassDeclarationValidator.d.ts.map