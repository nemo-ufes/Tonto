import { ValidationAcceptor } from "langium";
import { DataType } from "../generated/ast.js";
export declare class ComplexDataTypeValidator {
    /**
   * Verify if the class is not restricted with an incompatible Nature with this
   * class stereotype.
   */
    checkCompatibleNatures(complexDataType: DataType, accept: ValidationAcceptor): void;
    checkSpecialization(dataType: DataType, accept: ValidationAcceptor): void;
}
//# sourceMappingURL=ComplexDataTypeValidator.d.ts.map