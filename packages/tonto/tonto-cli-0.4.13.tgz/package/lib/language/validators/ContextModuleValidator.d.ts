import { ValidationAcceptor } from "langium";
import { ContextModule } from "../generated/ast.js";
export declare class ContextModuleValidator {
    checkContextModuleStartsWithCapital(contextModule: ContextModule, accept: ValidationAcceptor): void;
    checkDuplicatedClassName(contextModule: ContextModule, accept: ValidationAcceptor): void;
    /**
   * Checks if a ClassDeclaration has a ciclic specialization considering also
   * considering generalizationSets
   */
    checkCircularSpecialization(contextModule: ContextModule, accept: ValidationAcceptor): void;
    /**
   * Verify if the class declaration is a sortal and it's not an Ultimate
   * Sortal. Verify if it does not specialize any Ultimate Sortal, and
   * also verifies if it specialize more than one Ultimate Sortal. If
   * it is not restricted to the Type nature, then it shows an error that
   * it needs to specialize an Ultimate Sortal
   */
    checkClassDeclarationShouldSpecializeUltimateSortal(contextModule: ContextModule, accept: ValidationAcceptor): void;
    /**
   * Validate if a element have the correct nature based on specialization.
   * @param contextModule Actual ContextModule
   * @param accept Error creator helper
   */
    checkCompatibleNaturesOfBaseSortals(contextModule: ContextModule, accept: ValidationAcceptor): void;
    /**
   * Verify if the class restricts to Natures that is general class also
   * restricts
   */
    checkSpecializationNatureRestrictions(contextModule: ContextModule, accept: ValidationAcceptor): void;
    checkRedundantNatures(contextModule: ContextModule, accept: ValidationAcceptor): void;
}
//# sourceMappingURL=ContextModuleValidator.d.ts.map