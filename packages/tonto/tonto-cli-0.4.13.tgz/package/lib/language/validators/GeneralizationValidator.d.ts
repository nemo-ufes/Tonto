import { ValidationAcceptor } from "langium";
import { GeneralizationSet } from "../generated/ast.js";
export declare class GeneralizationValidator {
    /**
   * Verifica se o tipo de elemento do general (classe ou relation) é diferente do específico, dando erro caso seja.
   */
    checkGeneralizationSetConsistency(genSet: GeneralizationSet, accept: ValidationAcceptor): void;
    /**
   * Verifica se a generalização é circular
   */
    checkCircularGeneralization(genSet: GeneralizationSet, accept: ValidationAcceptor): void;
    /**
   * Verify if it is a generalization between two classes. Verify if
   * the general has a sortal stereotype and the specific has a non
   * sortal stereotype. If it has, the generalization is forbidden
   */
    checkGeneralizationSortality(genSet: GeneralizationSet, accept: ValidationAcceptor): void;
    /**
   * Verify if it is a generalization between two classes. Verify if the general
   * has an Anti Rigid stereotype and the specific has a Rigid or Anti Rigid
   * stereotype.
   */
    checkRigidSpecializesAntiRigid(genSet: GeneralizationSet, accept: ValidationAcceptor): void;
    /**
   * Verify if it is a generalization between two classes. Verify if the general
   * class has a DataType stereotype and the specific too
   */
    checkGeneralizationDataType(_genSet: GeneralizationSet, _accept: ValidationAcceptor): void;
}
//# sourceMappingURL=GeneralizationValidator.d.ts.map