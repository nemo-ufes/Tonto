import { ValidationAcceptor } from "langium";
import { Model } from "../generated/ast.js";
export declare class ModelValidator {
    checkDuplicatedContextModuleNames(_model: Model, _accept: ValidationAcceptor): void;
}
//# sourceMappingURL=ModelValidator.d.ts.map