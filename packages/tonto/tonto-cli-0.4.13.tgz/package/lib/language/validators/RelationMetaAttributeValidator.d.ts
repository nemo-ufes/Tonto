import { type ValidationAcceptor } from "langium";
import { type RelationMetaAttribute } from "../generated/ast.js";
import type { TontoServices } from "../tonto-module.js";
export declare class RelationMetaAttributeValidator {
    private readonly services;
    private readonly astNodeLocator;
    private readonly documents;
    private readonly indexManager;
    constructor(services: TontoServices);
    checkRelationEndOverrideUsesNamedEnd: (metaAttribute: RelationMetaAttribute, accept: ValidationAcceptor) => void;
    checkRelationEndDoesNotRedefineItself: (metaAttribute: RelationMetaAttribute, accept: ValidationAcceptor) => void;
    private checkSpecificRelationEndOverride;
    private buildNamedEndRequirementMessage;
    private getNamedEnds;
    private buildSelfRedefinitionMessage;
    private findVisibleRelation;
    private getPreferredRelationReference;
    private getVisibleRelationDescriptions;
    private loadRelation;
}
//# sourceMappingURL=RelationMetaAttributeValidator.d.ts.map