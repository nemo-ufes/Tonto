import { ClassDeclarationValidator } from "./ClassDeclarationValidator.js";
import { ComplexDataTypeValidator } from "./ComplexDataTypeValidator.js";
import { ContextModuleValidator } from "./ContextModuleValidator.js";
import { GeneralizationValidator } from "./GeneralizationValidator.js";
import { ModelValidator } from "./ModelValidator.js";
import { RelationMetaAttributeValidator } from "./RelationMetaAttributeValidator.js";
import type { TontoServices } from "../tonto-module.js";
export declare class TontoValidator {
    ContextModuleValidator: ContextModuleValidator;
    ClassDeclarationValidator: ClassDeclarationValidator;
    ModelValidator: ModelValidator;
    GeneralizationValidator: GeneralizationValidator;
    ComplexDataTypeValidator: ComplexDataTypeValidator;
    RelationMetaAttributeValidator: RelationMetaAttributeValidator;
    constructor(services: TontoServices);
}
//# sourceMappingURL=TontoValidator.d.ts.map