import { BuiltInLib } from "../../../cli/model/BuiltInLib.js";
import { basicDataTypes } from "./basicDataTypes.js";
declare const builtInLibs: BuiltInLib[];
export { builtInLibs, basicDataTypes };
//# sourceMappingURL=index.d.ts.map