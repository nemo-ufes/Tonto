import { DefaultWorkspaceManager } from "langium";
export declare class TontoWorkspaceManager extends DefaultWorkspaceManager {
}
//# sourceMappingURL=tonto-workspace-manager.d.ts.map