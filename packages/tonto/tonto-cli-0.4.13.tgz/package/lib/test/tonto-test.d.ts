import { AstNode, LangiumDocument } from "langium";
import { Diagnostic } from "vscode-languageserver";
import { TontoServices } from "../language/tonto-module.js";
/**
 * @param services: The Tonto Services
 * @returns a LangiumDocument containing the input contents and it's parsing results
 * This function uses the Tonto Services and parse a "False file" as a string input,
 * helping to test
 */
export declare function parseHelper<T extends AstNode = AstNode>(services: TontoServices): (input: string) => Promise<LangiumDocument<T>>;
export interface ValidationResult<T extends AstNode = AstNode> {
    diagnostics: Diagnostic[];
    document: LangiumDocument<T>;
}
/**
 *
 * @param services: Tonto services
 * @returns a ValidationResult containing the results of the validations that the
 * TontoServices did
 */
export declare function validationHelper<T extends AstNode = AstNode>(services: TontoServices): (input: string) => Promise<ValidationResult<T>>;
//# sourceMappingURL=tonto-test.d.ts.map