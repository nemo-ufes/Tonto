export {};
//# sourceMappingURL=isClassDeclaration.d.ts.map