export declare function notEmpty<TValue>(value: TValue | null | undefined): value is TValue;
//# sourceMappingURL=isEmpty.d.ts.map