import * as fs from "fs";
import { CompositeGeneratorNode, toString } from "langium/generate";
import { OntoumlElement, OntoumlType, Package, Project } from "ontouml-js";
import * as path from "path";
import { normalizeTontoGenerationError, TONTO_GENERATION_STEPS } from "../requests/tontoGeneration.js";
import { formatForId, replaceWhitespace } from "../utils/replaceWhitespace.js";
import { createTontoImports } from "./importModular.constructor.js";
import { createTontoManifest, customExtractDestinationAndName } from "./manifest.constructor.js";
import { createTontoPackage } from "./package.constructor.js";

export function generateTontoFile(project: Project, filePath: string, destination: string | undefined): string {
    const data = customExtractDestinationAndName(filePath, destination);
    const ctx = <GeneratorContext>{
        project,
        name: data.name,
        destinationFolder: data.destination,
        fileNode: new CompositeGeneratorNode(),
    };
    return generate(ctx);
}

interface GeneratorContext {
    project: Project
    name: string
    destinationFolder: string
    fileNode: CompositeGeneratorNode
}

function generate(ctx: GeneratorContext): string {
    try {
        if (!fs.existsSync(ctx.destinationFolder)) {
            fs.mkdirSync(ctx.destinationFolder, { recursive: true });
        }
    } catch (error) {
        throw normalizeTontoGenerationError(
            error,
            `Could not create the destination folder for "${ctx.name}".`,
            TONTO_GENERATION_STEPS.fileWriting
        );
    }

    try {
        createTontoManifest(ctx.project, ctx.destinationFolder);
    } catch (error) {
        throw normalizeTontoGenerationError(
            error,
            `Could not create the Tonto manifest for "${ctx.name}".`,
            TONTO_GENERATION_STEPS.fileWriting
        );
    }

    const modelPath = path.join(ctx.destinationFolder, formatForId(ctx.project.model?.getNameOrId()));

    try {
        if (!fs.existsSync(modelPath)) {
            fs.mkdirSync(modelPath);
        }
    } catch (error) {
        throw normalizeTontoGenerationError(
            error,
            `Could not create the model folder for "${ctx.name}".`,
            TONTO_GENERATION_STEPS.fileWriting
        );
    }

    const packages = ctx.project.model.getAllPackages();

    packages.forEach((ontoumlElement) => {
        generateModel(modelPath, ontoumlElement, new CompositeGeneratorNode());
    });

    // generateProject(modelPath, ctx.project, new CompositeGeneratorNode());

    return modelPath;
}

function generateModel(
    actualDestinationFolder: string,
    ontoumlElement: OntoumlElement,
    fileNode: CompositeGeneratorNode
) {
    /**
  * If it is a Project, we generate a Package with its elements, and then just 
  * enter the "Model" Package
  */
    if (ontoumlElement.type === OntoumlType.PROJECT_TYPE) {
        generateModel(actualDestinationFolder, ontoumlElement, new CompositeGeneratorNode());
    }
    /**
  * If it is a package, we need to generate again recursively
  */
    generatePackage(actualDestinationFolder, ontoumlElement, fileNode);
}

function generatePackage(dir: string, ontoumlElement: OntoumlElement, fileNode: CompositeGeneratorNode) {
    if (ontoumlElement.type === OntoumlType.PACKAGE_TYPE) {
        const packageElement = ontoumlElement as Package;
        const packageName = packageElement.getNameOrId();
        // Create directory for this package
        const packagePath = path.join(dir, formatForId(packageElement.getName()));
        let newPath: string = packagePath;
        try {
            if (!fs.existsSync(packagePath)) {
                newPath = fs.mkdirSync(packagePath, { recursive: true }) ?? packagePath;
            }
        } catch (error) {
            throw normalizeTontoGenerationError(
                error,
                `Could not create the package folder for "${packageName}".`,
                TONTO_GENERATION_STEPS.fileWriting
            );
        }

        try {
            createTontoImports(packageElement, fileNode);
            createTontoPackage(packageElement, fileNode);
        } catch (error) {
            throw normalizeTontoGenerationError(
                error,
                `Could not generate the Tonto source for package "${packageName}".`,
                TONTO_GENERATION_STEPS.packageGeneration
            );
        }

        // Lastly, we call it again to create other packages inside it recursively
        for (const child of packageElement.getContents()) {
            if (child.type === OntoumlType.PACKAGE_TYPE || child.type === OntoumlType.PROJECT_TYPE) {
                generateModel(replaceWhitespace(newPath), child, new CompositeGeneratorNode());
            }
        }

        const generatedFilePath = path.join(newPath, formatForId(packageElement.getName())) + ".tonto";
        try {
            fs.writeFileSync(generatedFilePath, toString(fileNode));
        } catch (error) {
            throw normalizeTontoGenerationError(
                error,
                `Could not write the generated Tonto file "${path.basename(generatedFilePath)}".`,
                TONTO_GENERATION_STEPS.fileWriting
            );
        }
    }
}

// function generateProject(dir: string, project: Project, fileNode: CompositeGeneratorNode) {
//   const rootPackageElements = project.model.getContents().filter(
//     item => item.type === OntoumlType.CLASS_TYPE ||
//       item.type === OntoumlType.GENERALIZATION_SET_TYPE ||
//       item.type === OntoumlType.RELATION_TYPE
//   );

//   // Create directory for this package
//   const packagePath = path.join(dir, formatForId(project.getNameOrId()));
//   if (!fs.existsSync(packagePath)) {
//     fs.mkdirSync(packagePath, { recursive: true }) ?? packagePath;
//   }

//   // Create the package
//   const packageItem = new Package({
//     name: new MultilingualText(formatForId(project.getNameOrId())),
//     id: project.getNameOrId(),
//     contents: rootPackageElements as ModelElement[]
//   });

//   createTontoImports(packageItem, fileNode);

//   createTontoPackage(packageItem, fileNode);

//   const generatedFilePath = path.join(packagePath, formatForId(packageItem.getNameOrId())) + ".tonto";
//   fs.writeFileSync(generatedFilePath, toString(fileNode));
// }
