export const mainTontoBlankFile = 
`package main

// 'kind' is a fundamental, rigid type.
// 'HelloWorld' is a kind, representing a basic concept.
kind HelloWorld {
    message: string
}
`;