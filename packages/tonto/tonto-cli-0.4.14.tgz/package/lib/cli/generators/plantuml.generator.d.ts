import type { AstNode } from "langium";
import { ContextModule, Model } from "../../language/generated/ast.js";
export interface PlantUMLOptions {
    showExternalReferences: boolean;
    /**
     * Group local elements inside a `package` box named after their owning module.
     * The focused/main package is never boxed. Defaults to true.
     */
    showPackageNames?: boolean;
    /** Group elements from external packages inside their own `package` box. Defaults to true. */
    groupExternalPackages?: boolean;
    /** Include only these packages when generating a full multi-package diagram. Defaults to all packages. */
    includedPackageNames?: string[];
    /** Show the owning package in card labels, such as `University::Room`. Defaults to true. */
    showPackageNamesInCards?: boolean;
    /** Render class/datatype attributes. Defaults to true. */
    showAttributes?: boolean;
    /** Render relation cardinalities. Defaults to true. */
    showCardinalities?: boolean;
    /** Render relation names and inverseOf labels. Defaults to true. */
    showRelationNames?: boolean;
    /** Fill elements with their nature color. When false the diagram is monochrome. Defaults to true. */
    showColors?: boolean;
    /** Spacing between nodes and ranks. Defaults to "cozy". */
    spacing?: PlantUMLSpacing;
    /** Scale element boxes up according to how many relations connect to them. Defaults to true. */
    sizeByDegree?: boolean;
    layout?: PlantUMLLayoutVariant;
    orthogonal?: boolean;
    externalReferenceModules?: ContextModule[];
}
export type PlantUMLSpacing = "compact" | "cozy" | "spacious";
export interface PlantUMLNatureLegendEntry {
    color: string;
    label: string;
}
/**
 * Nature → color mapping rendered by the generator, exposed so the editor can
 * draw a matching legend. These values come directly from the semantic-token palette.
 */
export declare const plantUMLNatureLegend: PlantUMLNatureLegendEntry[];
export type PlantUMLLayoutVariant = "default" | "top-to-bottom" | "left-to-right" | "polyline" | "orthogonal" | "smetana" | "elk";
export type PlantUMLSource = Model | ContextModule | ContextModule[] | AstNode;
export declare function generatePlantUML(model: PlantUMLSource, options?: PlantUMLOptions): string;
//# sourceMappingURL=plantuml.generator.d.ts.map