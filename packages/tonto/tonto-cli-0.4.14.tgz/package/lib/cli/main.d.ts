import { Command } from "commander";
import { TontoActions } from "./actions/actions.js";
export declare const cliVersion = "0.4.14";
export declare function createCli(actions?: TontoActions): Command;
export default function main(argv?: string[]): Promise<void>;
export * from "./actions/index.js";
export * from "./requests/jsonGeneration.js";
export * from "./requests/tontoGeneration.js";
export * from "./model/grammar/TontoManifest.js";
export * from "./requests/gufoTransform.js";
export * from "./requests/ontoumljsValidator.js";
export * from "./utils/buildFolderDocuments.js";
export * from "./utils/readManifest.js";
//# sourceMappingURL=main.d.ts.map