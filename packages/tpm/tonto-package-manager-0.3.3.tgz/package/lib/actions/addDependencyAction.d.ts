export interface TontoDependency {
    url: string;
    version?: string;
    directory?: string;
    branch?: string;
}
interface AddOptions {
    name: string;
    url: string;
    version?: string;
    dir?: string;
}
export declare const addDependencyAction: (currentDir: string, opts: AddOptions) => Promise<void>;
export {};
//# sourceMappingURL=addDependencyAction.d.ts.map