import { TontoDependency } from "./addDependencyAction.js";
export interface TontoManifest {
    projectName: string;
    displayName: string;
    publisher: string;
    version: string;
    license: string;
    dependencies: {
        [key: string]: TontoDependency;
    };
    outFolder: string;
    authors: Author[];
}
export interface Author {
    name: string;
    email?: string;
    url?: string;
}
interface InstallOptions {
    dir: string;
}
interface InstallResponse {
    fail: boolean;
    message: string;
}
declare const installAction: (opts: InstallOptions) => Promise<void>;
declare const installCommand: (opts: InstallOptions) => Promise<InstallResponse>;
export { installAction, installCommand };
//# sourceMappingURL=installAction.d.ts.map