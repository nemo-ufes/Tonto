export default function (): void;
export * from "./actions/installAction.js";
export * from "./actions/addDependencyAction.js";
//# sourceMappingURL=index.d.ts.map