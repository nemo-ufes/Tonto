import * as fs from "node:fs";
import * as path from "node:path";
import { readTontoManifest } from "tonto-cli";


export interface TontoDependency {
  url: string;
  version?: string;
  directory?: string;
  branch?: string;
}
interface AddOptions {
  name: string;
  url: string;
  version?: string;
  dir?: string;
}

export const addDependencyAction = async (currentDir: string, opts: AddOptions): Promise<void> => {
  const formattedDir = opts.dir ? opts.dir.trim() : opts.dir;
  const dependency = {
    url: opts.url.trim(),
    version: opts.version,
    directory: formattedDir,
  } as TontoDependency;

  // Read the JSON file
  const manifest = readTontoManifest(currentDir);

  if (manifest) {
    // Add the new dependency
    const formattedName = opts.name.trim();
    manifest.dependencies[formattedName] = dependency;
  } else {
    console.log("Tonto Manifest file not found!");
    return;
  }

  // Write the updated JSON back to the file
  const folderAbsolutePath = path.resolve(currentDir);
  const manifestPath = path.join(folderAbsolutePath, "tonto.json");
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  console.log(`Tonto dependency "${opts.name}" added successfully.`);
};
