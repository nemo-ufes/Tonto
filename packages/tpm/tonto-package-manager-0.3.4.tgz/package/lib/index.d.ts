import { Command } from "commander";
export declare function createTpmProgram(): Command;
export default function (argv?: readonly string[]): Promise<void>;
export * from "./actions/installAction.js";
export * from "./actions/addDependencyAction.js";
//# sourceMappingURL=index.d.ts.map